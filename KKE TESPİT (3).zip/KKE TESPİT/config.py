# config.py

ROBOFLOW_API_KEY = "njaeI4xUSjjdBYFcXo4P"
PROJECT_NAME = "testing-roboflow-k8mml"
PROJECT_VERSION = 1

# Kamera indeksini buraya girin (genellikle 0, 1, 2 vb.)
CAMERA_INDEX = 0

# Model parametreleri
CONFIDENCE_THRESHOLD = 40
OVERLAP_THRESHOLD = 30
